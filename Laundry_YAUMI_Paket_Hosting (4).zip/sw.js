const C='laundry-yaumi-2026-11-16b-donut';
const FILES=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png','./icon-maskable-512.png'];
const CORE=['./','./index.html'];
async function clean(r){if(!r.redirected)return r;const b=await r.blob();return new Response(b,{status:200,statusText:'OK',headers:r.headers});}
self.addEventListener('install',e=>{e.waitUntil((async()=>{
  const c=await caches.open(C);
  for(const f of FILES){
    try{const r=await fetch(new Request(f,{cache:'reload'}));if(r.ok)await c.put(f,await clean(r));else if(CORE.indexOf(f)>=0)throw new Error('gagal '+f);}
    catch(err){if(CORE.indexOf(f)>=0)throw err;}
  }
  await self.skipWaiting();
})());});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==C).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{
  const req=e.request;if(req.method!=='GET'||new URL(req.url).origin!==self.location.origin)return;
  e.respondWith((async()=>{
    const c=await caches.open(C);
    const hit=await c.match(req,{ignoreSearch:true});
    const upd=fetch(req).then(r=>{if(r&&r.ok&&!r.redirected)c.put(req,r.clone()).catch(()=>{});return r;});
    if(hit){upd.catch(()=>{});return hit;}
    try{return await upd;}
    catch(err){
      if(req.mode==='navigate'){const f=await c.match('./index.html')||await c.match('./');if(f)return f;}
      return new Response('Offline',{status:503,statusText:'Offline'});
    }
  })());
});
